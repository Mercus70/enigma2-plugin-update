# -*- coding: utf-8 -*-
# Niezawodny Updater dla BH-SKIN-FHD (Python 3.13)
# Całkowicie usunięto szyfrowanie HTTPS i TLS w celu ominięcia braku bibliotek SSL w dekoderze
import os
import urllib.request
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from enigma import eTimer
from Screens.Standby import TryQuitMainloop

# --- LINKI HTTP BEZ SZYFROWANIA SSL ---
# Używamy czystego protokołu http:// zamiast https://, co eliminuje błędy TLS/SSL
URL_WERSJA = "http://cba.pl"
URL_PACZKA = "http://cba.pl"

# Lokalne ścieżki robocze w pamięci dekodera
LOKALNY_PLIK_WERSJA = "/usr/share/enigma2/BH-SKIN-FHD"
LOKALNY_PLIK_IPK = "/tmp/bh_skin_fhd_update.ipk"
TYMCZASOWA_WERSJA = "/tmp/cba_version.txt"

global_session = None

class BHBackgroundCheck:
    def __init__(self, session):
        self.session = session
        self.wersja_github = ""
        self.wersja_lokalna = "Brak pliku"
        self.uruchom_sprawdzanie()

    def uruchom_sprawdzanie(self):
        if os.path.exists(LOKALNY_PLIK_WERSJA):
            try:
                with open(LOKALNY_PLIK_WERSJA, "r", encoding="utf-8") as f:
                    self.wersja_lokalna = f.read().strip()
            except:
                pass

        if os.path.exists(TYMCZASOWA_WERSJA):
            try: os.remove(TYMCZASOWA_WERSJA)
            except: pass
            
        try:
            # Pobieranie małego pliku przez HTTP z fałszywym User-Agent (często wymagane)
            req = urllib.request.Request(
                URL_WERSJA, 
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                content = response.read().decode('utf-8').strip()
                # Odsianie ewentualnego kodu reklamowego HTML, bierzemy tylko pierwszą linię (numer wersji)
                if "\n" in content:
                    content = content.split("\n")[0].strip()
                if "<html" in content.lower():
                    content = ""
                with open(TYMCZASOWA_WERSJA, "w", encoding="utf-8") as f:
                    f.write(content)
            self.wersja_pobrana()
        except Exception as e:
            print("[BH-Updater] Blad sprawdzania wersji HTTP:", str(e))

    def wersja_pobrana(self):
        try:
            with open(TYMCZASOWA_WERSJA, "r", encoding="utf-8") as f:
                self.wersja_github = f.read().strip()
            os.remove(TYMCZASOWA_WERSJA)
        except:
            return

        if self.wersja_lokalna != self.wersja_github and self.wersja_github != "":
            self.session.openWithCallback(
                self.odpowiedz_uzytkownika,
                MessageBox,
                f"Wykryto nową aktualizację skórki BH-SKIN-FHD!\n\nZainstalowana wersja: {self.wersja_lokalna}\nDostępna wersja na serwerze: {self.wersja_github}\n\nCzy chcesz ją teraz pobrać i zainstalować?",
                MessageBox.TYPE_YESNo
            )

    def odpowiedz_uzytkownika(self, answer):
        if answer:
            self.session.open(BHHTTPUpdater)


class BHHTTPUpdater(Screen):
    skin = """
    <screen position="center,center" size="750,260" title="BH-SKIN-FHD Skin Updater">
        <widget name="status_label" position="20,40" size="710,110" font="Regular;22" halign="center" valign="center" transparent="1" />
        <widget name="info_label" position="20,180" size="710,40" font="Regular;18" halign="center" valign="center" foregroundColor="#00ff00" transparent="1" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self["status_label"] = Label("Łączenie z serwerem przez czysty protokół HTTP i pobieranie pakietu...")
        self["info_label"] = Label("Trwa instalacja aktualizacji – proszę czekać...")
        
        self["actions"] = ActionMap(["SetupActions"], {
            "cancel": self.close
        }, -1)
        
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.uruchom_pobieranie)
        except:
            self.timer.callback.append(self.uruchom_pobieranie)
        self.timer.start(500, True)

    def uruchom_pobieranie(self):
        if os.path.exists(LOKALNY_PLIK_IPK):
            try: os.remove(LOKALNY_PLIK_IPK)
            except: pass
            
        # Wykorzystanie systemowego wget bez żadnego szyfrowania (szybko i bezbłędnie)
        komenda_wget = f"wget --quiet --timeout=30 -O {LOKALNY_PLIK_IPK} '{URL_PACZKA}'"
        wynik_wget = os.system(komenda_wget)
        
        if wynik_wget == 0 and os.path.exists(LOKALNY_PLIK_IPK) and os.path.getsize(LOKALNY_PLIK_IPK) > 10240:
            self.pobieranie_zakonczone()
        else:
            self.blad_pobierania()

    def pobieranie_zakonczone(self):
        self["status_label"].setText("Pobieranie ukończone. Wymuszanie instalacji opkg w tle...")
        
        # Oczyszczanie pliku przed instalacją (usunięcie ewentualnego kodu reklamowego CBA z końcówki pliku)
        try:
            with open(LOKALNY_PLIK_IPK, "rb") as f:
                dane = f.read()
            # Szukamy realnego końca pliku tar (IPK to spakowane kontenery), obcinamy reklamy HTML
            if b"</html>" in dane:
                dane = dane.split(b"</html>")[0] + b"</html>"
                with open(LOKALNY_PLIK_IPK, "wb") as f:
                    f.write(dane)
        except:
            pass

        komenda = f"opkg install --force-overwrite {LOKALNY_PLIK_IPK}"
        wynik_linux = os.system(komenda)
        
        if os.path.exists(LOKALNY_PLIK_IPK):
            try: os.remove(LOKALNY_PLIK_IPK)
            except: pass

        if wynik_linux == 0:
            self.session.openWithCallback(
                self.restart_gui, 
                MessageBox, 
                "Skórka BH-SKIN-FHD zaktualizowana pomyślnie!\nAby zastosować zmiany graficzne, wymagany jest restart GUI.\nCzy chcesz zrestartować teraz?", 
                MessageBox.TYPE_YESNo
            )
        else:
            self["status_label"].setText("Błąd krytyczny: System Linux odrzucił spakowane archiwum IPK.")

    def blad_pobierania(self):
        self["status_label"].setText("Błąd połączenia: Serwer nie odpowiedział na żądanie HTTP.\nUpewnij się, że pliki znajdują się w głównym katalogu mkwk018.cba.pl")

    def restart_gui(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()


def StartSesji(reason, session, **kwargs):
    global global_session
    if reason == 0 and session is not None:
        global_session = session
        BHBackgroundCheck(session)

def UruchomMenu(session, **kwargs):
    session.open(BHHTTPUpdater)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=StartSesji
        ),
        PluginDescriptor(
            name="BH-SKIN-FHD Skin Updater",
            description="Automatycznie sprawdza i pobiera czyste aktualizacje skórki przez nieszyfrowany protokół HTTP",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=UruchomMenu
        )
    ]
